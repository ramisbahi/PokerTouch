//
//  Shuffler.swift
//  PokerTouch
//
//  Created by Subhi Sbahi on 5/28/17.
//  Copyright © 2017 Rami Sbahi. All rights reserved.
//

import Foundation

class Shuffler
{
    /*
    static func rotate(players: [String]) -> [String]
    {
        var returnArray = [String](repeating: "", count: players.count)
        let firstPlayer: Int = Int(arc4random_uniform(UInt32(players.count)))
        
        
        players = returnArray
        return players
    }*/

}
